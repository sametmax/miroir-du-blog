from django.conf.urls.defaults import *


urlpatterns = patterns('',
    (r'^$', 'app.views.hello'),

)
